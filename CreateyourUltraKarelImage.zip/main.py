#Precondition: Karol is in the bottom left corner with an empty world 
#Postcondition: Karol will make a capybara 

"""These are functions that will be used throughout the drawing"""


def foot():
    for i in range(2):
        move()
    for i in range(3):
        paint('black')
        move()

"""This is to create feet of the capybara"""


for i in range(10):
    move()
for i in range(2):
    foot()
for i in range(4):
    move()

for i in range(4):
    paint('black')
    move()
paint('black')
move()
turn_left()
move()
paint('black')
turn_left()
for i in range(4):
    move()
for i in range(5):
    move()
    paint('black')
for i in range(3):
    move()
for i in range(2):
    move()
    paint('black')
for i in range(4):
    move()
paint('black')
turn_right()
move()
paint('black')
turn_right()
for i in range(4):
    move()
paint('black')
move()
paint('black')
for i in range(3):
    move()
for i in range(3):
    move()
    paint('black')
for i in range(2):
    move()
for i in range(3):
    move()
    paint('black')
for i in range(2):
    move()
paint('black')

"""To make body of the capybara"""
for i in range(1):
    move()
paint('black')
turn_left()
move()
paint('black')
turn_left()
for i in range(3):
    move()
paint('black')
for i in range(5):
    move()
paint('black')
for i in range(2):
    move()
    paint('black')
for i in range(4):
    move()
for i in range(2):
    paint('black')
    move()
for i in range(3):
    move()
paint('black')
turn_right()
move()
paint('black')
turn_right()
move()
move()
move()
for i in range(3):
    paint('black')
    move()
for i in range(3):
    move()
for i in range(8):
    paint('black')
    move()
move()
move()
move()
paint('black')
turn_left()
move()
turn_left()
paint('black')
move()
move()
move()
move()
paint('black')
for i in range(7):
    move()
paint('black')
for i in range(4):
    move()
for i in range(2):
    paint('black')
    move()
for i in range(1):
    move()
paint('black')
for i in range(2):
    move()
paint('black')
turn_right()
move()
turn_right()
paint('black')
move()
paint('black')
for i in range(3):
    move()
paint('black')
move()
paint('black')
for i in range(4):
    move()
paint('black')
for i in range(6):
    move()
paint('black')
for i in range(6):
    move()
paint('black')
turn_left()
move()
paint('black')
turn_left()
for i in range(7):
    move()
paint('black')
for i in range(10):
    move()
paint('black')
for i in range(4):
    move()
paint('black')
move()
turn_right()
move()
paint('black')
turn_right()
for i in range(15):
    move()
paint('black')
for i in range(7):
    move()
paint('black')
turn_left()
move()
paint('black')
turn_left()
for i in range(7):
    move()
paint('black')
for i in range(15):
    move()
paint('black')
turn_right()
move()
paint('black')
turn_right()
for i in range(15):
    move()
paint('black')
for i in range(7):
    move()
paint('black')
turn_left()
move()
paint('black')
turn_left()
for i in range(6):
    move()
paint('black')
for i in range(16):
    move()
paint('black')
turn_right()
move()
paint('black')
turn_right()
for i in range(22):
    move()
paint('black')
turn_left()
move()
paint('black')
turn_left()
for i in range(22):
    move()
paint('black')
turn_right()
move()
paint('black')
turn_right()
for i in range(4):
    paint('black')
    move()
for i in range(18):
    move()
paint('black')
turn_left()
move()
paint('black')
turn_left()
for i in range(23):
    move()
turn_left()
move()
paint('black')
turn_right()
move()
paint('black')
turn_right()
move()
turn_left()
move()
paint('black')
turn_right()
move()
turn_left()
move()
paint('black')
turn_right()
turn_right()
for i in range(26):
    move()
paint('black')
turn_left()
move()
turn_left()
move()
paint('black')
for i in range(26):
    move()
paint('black')
turn_right()
move()
paint('black')
turn_right()
for i in range(2):
    move()
for i in range(2):
    paint('black')
    move()
for i in range(2):
    move()
    paint('black')
for i in range(19):
    move()
for i in range(2):
    paint('black')
    move()
turn_left()
move()
turn_left()
move()
for i in range(2):
    move()
    paint('black')
for i in range(20):
    move()
paint('black')
for i in range(4):
    move()
paint('black')
turn_right()
move()
paint('black')
turn_right()
move()
for i in range(3):
    move()
paint('black')
for i in range(19):
    move()
paint('black')
move()
paint('black')
turn_left()
move()
turn_left()
move()
paint('black')
for i in range(23):
    move()
paint('black')
turn_right()
move()
turn_right()
paint('black')
move()
move()
for i in range(2):
    paint('black')
    move()
move()
for i in range(2):
    paint('black')
    move()

"""To make capybara face"""
for i in range(16):
    move()
paint('black')
turn_left()
move()
paint('black')
turn_left()
for i in range(6):
    move()
paint('black')
move()
move()
paint('black')
for i in range(15):
    move()
paint('black')
turn_right()
move()
turn_right()
move()
paint('black')
for i in range(15):
    move()
paint('black')
for i in range(7):
    move()
paint('black')
turn_left()
move()
paint('black')
turn_left()
for i in range(21):
    move()
paint('black')
turn_right()
move()
turn_right()
move()
paint('black')
for i in range(19):
    move()
paint('black')
turn_left()
move()
paint('black')
turn_left()
for i in range(18):
    move()
paint('black')
turn_right()
"""Capybara forehead"""
move()
turn_right()
move()
for i in range(2):
    paint('black')
    move()
for i in range(13):
    move()
for i in range(2):
    paint('black')
    move()
turn_left()
move()
turn_left()
for i in range(2):
    move()
for i in range(2):
    paint('black')
    move()
for i in range(11):
    move()
for i in range(2):
    paint('black')
    move()
turn_right()
move()
turn_right()
move()
move()
for i in range(10):
    move()
    paint('black')
"""To make capybara ears"""
for i in range(2):
    move()
paint('black')
turn_left()
move()
paint('black')
move()
turn_left()
move()
paint('black')
move()
turn_left()
move()
paint('black')
turn_right()
for i in range(9):
    move()
paint('black')
turn_right()
move()
turn_left()
move()
paint('black')
move()
turn_left()
move()
paint('black')
move()
paint('black')